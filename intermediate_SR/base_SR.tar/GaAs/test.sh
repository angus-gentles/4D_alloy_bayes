#!/bin/sh
#SBATCH -J test
#SBATCH --output=GA_ato.txt
#SBATCH -n 40
#SBATCH --ntasks-per-node=40
#SBATCH --time 7-00:00:00   # max runtime hh:mm:ss
#SBATCH --exclude=tcad39,tcad35

# SBATCH --nodelist=tcad39
# SBATCH  --qos=zen3_0512_devel
module load mpi/mvapich2-psm2-x86_64
export PATH="/home/gentles/tools/sc-qe-7.3/bin:$PATH"
which pw.x
which mpirun
mpirun -n ${SLURM_NPROCS} pw.x -i In0.0Ga1.0As1.0Sb0.0_square_rep_0.relax.in > In0.0Ga1.0As1.0Sb0.0_square_rep_0.relax.out
#pw.x -i In0.0Ga1.0As1.0Sb0.0_square_rep_0.relax.in > In0.0Ga1.0As1.0Sb0.0_square_rep_0.relax.out